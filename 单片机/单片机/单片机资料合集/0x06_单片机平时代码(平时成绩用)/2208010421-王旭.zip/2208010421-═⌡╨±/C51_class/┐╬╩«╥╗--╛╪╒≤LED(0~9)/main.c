#include "reg52.h"
#define SMG A_2_DP_PORT P0
#define LED_MATRIX_COL_PORT P0

typedef unsigned int u16;
typedef unsigned char u8;
sbit HC595_SER = P3 ^ 4;
sbit HC595_SRCLK = P3 ^ 6;
sbit HC595_RCLK = P3 ^ 5;
u8 code led_matrix_col_codes[] = {
    0x7f, 0xbf, 0xdf, 0xef, 0xf7, 0xfb, 0xfd, 0xfe
};

u8 code led_matrix_row_codes[][8] = {
                      {0x00,0x00,0x3e,0x41,0x41,0x41,0x3e,0x00},     //0
                      {0x00,0x00,0x00,0x21,0x7f,0x01,0x00,0x00},     //1
                      {0x00,0x00,0x27,0x45,0x45,0x45,0x39,0x00},     //2
	                  {0x00,0x00,0x2a,0x49,0x49,0x49,0x36,0x00},     //3
                      {0x00,0x00,0x0c,0x14,0x24,0x7f,0x04,0x00},     //4
                      {0x00,0x00,0x72,0x51,0x51,0x51,0x4e,0x00},     //5
                      {0x00,0x00,0x3e,0x49,0x49,0x49,0x26,0x00},     //6
                      {0x00,0x00,0x40,0x40,0x4f,0x50,0x60,0x00},     //7
                      {0x00,0x00,0x36,0x49,0x49,0x49,0x36,0x00},     //8
                      {0x00,0x00,0x32,0x49,0x49,0x49,0x3e,0x00}, 
};

void delay_10us(u16 ten_us)
{
    while (ten_us--);
}
void led_matrix_display_init()
{
    LED_MATRIX_COL_PORT = 0xff; //
}

void hc595_write_data(u8 dat)
{
    u16 i = 0;
    for (i = 0; i < 8; i++)
    {
        HC595_SER = dat >> 7;
        dat <<= 1;
        HC595_SRCLK = 0;
        delay_10us(1);
        HC595_SRCLK = 1;
        delay_10us(1);
    }
    HC595_RCLK = 0;
    delay_10us(1);
    HC595_RCLK = 1;
    delay_10us(1);
}

void main()
{	
    u16 i,j,n;
    led_matrix_display_init();
    hc595_write_data(0x00);
    while (1)
    {
     
		for(i=0 ;i<80;i++){
		  for(j=0;j<8;j++){
		    LED_MATRIX_COL_PORT = led_matrix_col_codes[j];
	
			hc595_write_data(led_matrix_row_codes[n][j]);
		
			delay_10us(100);
			hc595_write_data(0x00);
		  
		  }	
    }
	n++;
	   if(n>=10){
		n=0;
       }
}}