#include"reg52.h"

typedef unsigned char u8;
typedef unsigned char u16;

sbit KEY_K3 = P3^2;

sbit SMG_LS_A2=P2^4;
sbit SMG_LS_A1=P2^3;
sbit SMG_LS_A0=P2^2;

void delay_10us(u16 ten_us){	 //��ʱ����
	while(ten_us--);
}

#define SMG_A_2_DP_PORT P0
u8 code smg_duan_codes[]={
   0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f
};
/*
     
*/

void main()
{

    
    while(1)
	2+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++{
	   SMG_LS_A2=0;
	   SMG_LS_A1=0;
	   SMG_LS_A0=0;	//1
	   SMG_A_2_DP_PORT=0x06;
	   delay_10us(50000);
	   
	   SMG_LS_A2=0;
	   SMG_LS_A1=0;
	   SMG_LS_A0=1;	//2
	   SMG_A_2_DP_PORT=0x5b;
	   delay_10us(50000);


	   SMG_LS_A2=0;
	   SMG_LS_A1=1;
	   SMG_LS_A0=0;//3
	   SMG_A_2_DP_PORT=0x4f;
	   delay_10us(50000);

	   SMG_LS_A2=0;
	   SMG_LS_A1=1;
	   SMG_LS_A0=1;//4
	   SMG_A_2_DP_PORT=0x66;
	   delay_10us(50000);

	   SMG_LS_A2=1;
	   SMG_LS_A1=0;
	   SMG_LS_A0=0;//5
	   SMG_A_2_DP_PORT=0x6d;
	   delay_10us(50000);

	   SMG_LS_A2=1;
	   SMG_LS_A1=0;
	   SMG_LS_A0=1;//6
	   SMG_A_2_DP_PORT=0x7d;
	   delay_10us(50000);

	   SMG_LS_A2=1;
	   SMG_LS_A1=1;
	   SMG_LS_A0=0;//7
	   SMG_A_2_DP_PORT=0x07;
	   delay_10us(50000);

	   SMG_LS_A2=1;
	   SMG_LS_A1=1;
	   SMG_LS_A0=1;//8
	   SMG_A_2_DP_PORT=0x7f;
	   delay_10us(50000);
	   
	}

}