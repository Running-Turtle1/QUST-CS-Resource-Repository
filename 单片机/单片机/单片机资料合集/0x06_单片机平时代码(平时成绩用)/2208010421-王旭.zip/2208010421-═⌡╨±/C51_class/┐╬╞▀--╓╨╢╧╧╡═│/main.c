#include"reg52.h"

typedef unsigned char u8;
typedef unsigned char u16;



sbit LED_D1=P2^0;

sbit LED_D2=P2^1;

sbit LED_D3=P2^2;

sbit LED_D4=P2^3;


sbit INT0_KEY_K3=P3^2;

sbit INT1_KEY_K4=P3^3;

sbit SMG_LS_A2=P2^4;
sbit SMG_LS_A1=P2^3;
sbit SMG_LS_A0=P2^2;

void delay_10us(u16 ten_us)
{
  while(ten_us--);
}

u8  int0_trigger_count=0;
u8  int1_trigger_count=0;

#define SMG_A_2_DP_PORT P0
#define SMG_A_2_DP_PORT2 P0
u8 code smg_duan_codes[]={
   0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f
};

void smg_display_init()//
{
    SMG_LS_A2=0;
	SMG_LS_A1=0;
	SMG_LS_A0=0;  
}

void smg_display_init1()//
{
    SMG_LS_A2=0;
	SMG_LS_A1=0;
	SMG_LS_A0=1;  
}

/*


*/
void extern_int0_init()		//�ⲿ�ж�INT0���жϷ������
{
  	 IT0=1;  //��һ����: �½�����Ч
	 
	 EX0=1;  //�ڶ����ţ�INT0�Ŀ�����

	 EA=1;   //�������ţ��ܿ�����

}

void extern_int1_init()	  //�ⲿ�ж�INT1���жϷ������
{
	 IT1=1;

	 EX1=1;

	 EA=1;
}

void main()
{  
   
   smg_display_init1();
   smg_display_init();
   extern_int0_init();
   extern_int1_init();
   while(1)
   {
     /*
       if(int0_trigger_count>9)   
	   {
	   	 int0_trigger_count=0;
	   }
	  */
	  if(int0_trigger_count>9)
	  {	 int0_trigger_count=0;
	     int1_trigger_count++;
	  }
	   SMG_A_2_DP_PORT=smg_duan_codes[int0_trigger_count];
	   SMG_A_2_DP_PORT2=smg_duan_codes[int1_trigger_count];
   }
}

void extern_int0_isr() interrupt 0
{
	  //1:ȥ����
	  delay_10us(1000);
	  //2:
	  if(INT0_KEY_K3==0)
	  {
	     LED_D1=!LED_D1;

		 int0_trigger_count++;	   //ͳ�ư��°����Ĵ���
		 int1_trigger_count++;
	  }

}

void extern_int1_isr() interrupt 2
{
      delay_10us(1000);

	  if(INT1_KEY_K4==0)
	  {
	    LED_D2=!LED_D2;

		//int0_trigger_count=0;//����K4����
	  }
}