//main.c?????????????
#include "public.h"
 float T;

void main()
{

	time0_1ms_init();
  ds18b20_init();
  delay_10us(1000);
  lcd1602_init();
 
  lcd1602_show_string(1,0,"Temprature:");
  while(1)
  {
     ds18b20_init();
	 
	 if(T<0)
	 {
	     (1,1,'-');
	   T=-T;
	 }
	 else
	 {
	   lcd1602_show_data(1,1,'+');
	 }
	  lcd1602_shownum(2,1,T,3);
	  lcd1602_show_data(5,1,'.');
	  lcd1602_shownum(6,1,(unsigned long)(T*10000)%10000,2);
	 delay_10us(100*1000);
  }
 			 
} 		

void T0_isr() interrupt 1{
	// 1s ??????
	static unsigned int counter = 0;
	counter ++;
	if(counter == 1000){ // 1000 * 1 = 1000 ms
		counter = 0; 
		T = ds18b20_read_temperature();
	}
	// ?? 1ms ????????
	TH0 = 0xFC;
	TL0 = 0x18;
}
