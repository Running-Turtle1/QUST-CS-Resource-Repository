#ifndef __ds1302_H__
#define __ds1302_H__

#include "public.h"

void ds1302_write_byte(u8 addr,u8 dat);
u8 ds1302_read_byte(u8 addr);
void ds1302_init(void);
void ds1302_read_real_time(void);

#endif