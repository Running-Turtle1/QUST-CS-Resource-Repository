#ifndef __LCD1602_H__
#define __LCD1602_H__

u8 code lcd1602_table[];


void lcd1602_busy_test();
void lcd1602_write_cmd(u8 cmd);
void lcd1602_write_data(u8 dat);
void lcd1602_init();
void lcd1602_clear(void);
void lcd1602_show_data(u8 x,u8 y,u8 dat);
void lcd1602_show_string(u8 x,u8 y,u8 *str);

int lcd1602_pow(int X,int Y);
void lcd1602_shownum(unsigned char Line,unsigned char Column,unsigned int Number,unsigned char Length);
#endif