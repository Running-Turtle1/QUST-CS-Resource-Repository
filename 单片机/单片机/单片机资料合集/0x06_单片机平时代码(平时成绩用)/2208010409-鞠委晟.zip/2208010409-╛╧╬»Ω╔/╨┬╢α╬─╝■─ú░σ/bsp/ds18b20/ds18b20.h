#ifndef __ds18b20_H__
#define __ds18b20_H__

 void ds18b20_reset();
 u8 ds18b20_check();
 void ds18b20_init();
 void ds18b20_write_byte(u8 dat);
 u8 ds18b20_read_byte();
 float ds18b20_read_temperature();


#endif