#ifndef __STEP_MOTOR_H__
#define __STEP_MOTOR_H__



void step_motor_4_beat_send_pulse(u8 dir,u8 step);
void step_motor_8_beat_send_pulse(u8 dir,u8 step);


#endif