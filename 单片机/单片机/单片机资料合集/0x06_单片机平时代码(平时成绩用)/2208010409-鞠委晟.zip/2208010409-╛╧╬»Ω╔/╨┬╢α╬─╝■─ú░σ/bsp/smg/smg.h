#ifndef __SMG_H__
#define __SMG_H__

u8 code g_smg_duan_code[];

void smg_1_2_refresh();
void smg_1_2_display(u8 pos,u8 i);
void smg_display(u8 dat[],u8 pos);
#endif