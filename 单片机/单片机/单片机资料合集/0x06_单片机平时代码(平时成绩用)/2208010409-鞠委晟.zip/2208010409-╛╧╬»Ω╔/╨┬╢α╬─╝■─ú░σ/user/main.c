//main.c��ֻ��Ҫ������ͬͷ�ļ�����
#include "public.h"
 float T;

void main()
{

  ds18b20_init();
  delay_10us(1000);
  lcd1602_init();
 
  lcd1602_show_string(1,0,"Temprature:");
  while(1)
  {
     ds18b20_init();
	 T = ds18b20_read_temperature();
	 if(T<0)
	 {
	     (1,1,'-');
	   T=-T;
	 }
	 else
	 {
	   lcd1602_show_data(9,1,'+');
	 }
	  lcd1602_shownum(10,1,T,3);
	  lcd1602_show_data(13,1,'.');
	  lcd1602_shownum(14,1,(unsigned long)(T*10000)%10000,2);
  }
 			 
} 		

