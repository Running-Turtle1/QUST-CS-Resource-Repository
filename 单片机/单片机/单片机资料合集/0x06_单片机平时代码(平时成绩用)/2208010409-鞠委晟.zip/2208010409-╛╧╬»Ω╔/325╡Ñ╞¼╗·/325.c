#include"reg52.h"
#define LEDS_PORT P2
typedef unsigned int u16;
typedef unsigned int u8;
sbit LED_D1=P2^0;
sbit LED_D2=P2^1;
sbit LED_D3=P2^2;
sbit LED_D4=P2^3;

sbit KEY_K1=P3^0;
sbit KEY_K2=P3^1;
sbit KEY_K3=P3^2;
sbit KEY_K4=P3^3;
void delay_10us(u16 ten_us){
	while(ten_us--);
}
void main()
{
	LED_D1=1;
		LED_D2=1;
			LED_D3=1;
				LED_D4=1;
	while(1){
	if(KEY_K1==0){
		delay_10us(1000);
		if(KEY_K1==0){
			LED_D1=0;
			while(KEY_K1==0);
	LED_D1=~LED_D1;
	}
	}
	if(KEY_K2==0){
		delay_10us(1000);
		if(KEY_K2==0){
			LED_D2=0;
			while(KEY_K2==0);
	LED_D2=~LED_D2;
	}
	}
	if(KEY_K3==0){
		delay_10us(1000);
		if(KEY_K3==0){
			LED_D3=0;
			while(KEY_K3==0);
			LED_D3=~LED_D3;}
			}
	if(KEY_K4==0){
		delay_10us(1000);
		if(KEY_K4==0){
			LED_D4=0;
			while(KEY_K4==0);
	LED_D4=~LED_D4;
		}
		}
	
	}
	
	
	}	