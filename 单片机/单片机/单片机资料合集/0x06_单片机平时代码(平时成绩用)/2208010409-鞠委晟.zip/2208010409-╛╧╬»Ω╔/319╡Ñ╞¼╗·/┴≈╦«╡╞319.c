#include"reg52.h"
#define LEDS_PORT P2
typedef unsigned int u16;
typedef unsigned int u8;

void delay_10us(u16 ten_us){
	while(ten_us--);
}
void main()
{
	/*P2 = 0xfe; // 1111 1110
	delay_10us(50000);
	
	P2 = 0xfd; // 1111 1101
	delay_10us(50000);
	
	P2 = 0xfb; // 1111 1011
	delay_10us(50000);
	
	P2 = 0xf7; // 1111 0111
	delay_10us(50000);
	
	P2 = 0xef; // 1110 1111
	delay_10us(50000);
	
	P2 = 0xdf; // 1101 1111
	delay_10us(50000);

	P2 = 0xbf; // 1011 1111
	delay_10us(50000);
	
	P2 = 0x7f; // 0111 1111
	delay_10us(50000);*/
	u8 i;
	LEDS_PORT=0x01;
	while(1){
	for(i=0;i<8;i++)
	{
	LEDS_PORT=~(0x01<<i);
	delay_10us(50000);
	}
	}
	
}