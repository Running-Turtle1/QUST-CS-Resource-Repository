#ifndef __STEP_MOTOR_H__
#define __STEP_MOTOR_H__
#include "public.h"

void step_motor_4_beat_control(int step);

#endif