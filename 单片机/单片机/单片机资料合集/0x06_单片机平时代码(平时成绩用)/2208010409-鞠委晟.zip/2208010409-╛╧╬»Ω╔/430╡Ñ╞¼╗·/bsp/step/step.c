#include"public.h"
void step_motor_4_beat_control(u8 step)
{
switch(step){
case 0:
STET_IN_D=1;
STET_IN_C=0;
STET_IN_B=0;
STET_IN_A=0;
break;
case 1:
STET_IN_D=0;
STET_IN_C=1;
STET_IN_B=0;
STET_IN_A=0;
break;

case 2:
STET_IN_D=0;
STET_IN_C=0;
STET_IN_B=1;
STET_IN_A=0;
break;

case 3:
STET_IN_D=0;
STET_IN_C=0;
STET_IN_B=0;
STET_IN_A=1;
break;
}


}