#include<reg52.h>
#include"led.h"
#include"public.h"

void leds_show_all_on(void)
{
 LED_PORT=0x00;
}
void leds_show_all_off(void)
{
 LED_PORT=0xFF;
}
void leds_show_all_runnig(void)
{
	
	u8 i;
	LED_PORT=0x01;
	while(1){
	for(i=0;i<8;i++)
	{
	LED_PORT=~(0x01<<i);
	delay_10us(500);
	}
}
}