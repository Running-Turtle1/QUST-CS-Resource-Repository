#ifndef __PUBLIC_H__
#define __PUBLIC_H__
//����ͷ�ļ�
#include<reg52.h>
#include "led.h"
#include "step.h"

#define u8 unsigned char
#define u16 unsigned int


#define LED_PORT P2


sbit LED__D1=P2^0;
sbit LED__D2=P2^1;
sbit LED__D3=P2^2;
sbit LED__D4=P2^3;
sbit LED__D5=P2^4;
sbit LED__D6=P2^5;
sbit LED__D7=P2^6;
sbit LED__D8=P2^7;
sbit KEY_K1=P3^0;
sbit KEY_K2=P3^1;
sbit KEY_K3=P3^2;
sbit KEY_K4=P3^3;
sbit STET_IN_D=P1^0;
sbit STET_IN_C=P1^1;
sbit STET_IN_B=P1^2;
sbit STET_IN_A=P1^3;

//��������

void delay_10us(u16 ten_us);

#endif