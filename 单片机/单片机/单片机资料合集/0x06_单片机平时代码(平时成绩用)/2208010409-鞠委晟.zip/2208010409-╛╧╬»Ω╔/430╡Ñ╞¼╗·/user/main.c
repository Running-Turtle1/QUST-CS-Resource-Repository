#include "public.h"
#include "led.h"
void main()
{
int step=0;

	while(1)
	{
step_motor_4_beat_control(step);
step++;
if(step>=4)
{
step=0;
}
delay_10us(500);
}
}
