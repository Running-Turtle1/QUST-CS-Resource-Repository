#include"reg52.h"
#define SMG_A_DP_PORT P0
#define KEY_MATRIX_PORT P1
// 					/E1	/E2		E3
//74HC138		4		 5		6
//shineng   0    0  	1
//					A2	 A1		A0
//					P24	 P23  P22





typedef unsigned int u16;
typedef unsigned char u8;

sbit KEY_K1 = P3^0;
sbit KEY_K2 = P3^1;
sbit KEY_K3 = P3^2;
sbit KEY_K4 = P3^3;

sbit SMG_LS_A2 = P2^4;
sbit SMG_LS_A1 = P2^3;
sbit SMG_LS_A0 = P2^2;


//dp g f e d c b a   
// 0 0 1 1 1 1 1 1  liang 0 0x3f
// 0 0 0 0 0 1 1 0  liang 1	0x06
// 0 1 0 1 1 0 1 1  liang 2 0x5b
// 0 1 0 0 1 1 1 1  liang 3 0x4f
// 0 1 1 0 0 1 1 0  liang 4 0x66
// 0 1 1 0 1 1 0 1  liang 5 0x6d
// 0 1 1 1 1 1 0 1  liang 6 0x7d
// 0 0 0 0 0 1 1 1  liang 7 0x07
// 0 1 1 1 1 1 1 1  liang 8 0x7f
// 0 1 1 0 1 1 1 1  liang 9 0x6f
// 1 1 1 1 0 1 1 1  liang a 0x6f
// 1 1 1 1 1 1 1 1  liang b 0x6f
// 0 0 1 1 1 0 0 1  liang c 0x6f
// 0 0 1 1 1 1 1 1  liang d 0x3f
// 0 1 1 1 1 0 0 1  liang e 0x79
// 0 1 1 1 0 0 0 1  liang f 0x71

/*
hang1 P17
hang2 P16
hang3 P15
hang4 P14

lie1	lie2	lie3	lie4
P13		P12		P11		P10


*/

void delay_10us(u16 ten_us){
	
	while(ten_us--);

}

void main(){

	while(1){
		
			KEY_MATRIX_PORT=0x0f;
		
			if(	KEY_MATRIX_PORT!=0x0f)
			{
				delay_10us(1000);
				if(KEY_MATRIX_PORT==0x07)
				{
					SMG_LS_A2 = 0;
					SMG_LS_A1 = 0;
					SMG_LS_A0 = 0;
				
					P0 = 0x06;
					while(KEY_MATRIX_PORT==0x07);
					P0 = 0x00;
				}else if(KEY_MATRIX_PORT == 0x0b){
					SMG_LS_A2 = 0;
					SMG_LS_A1 = 0;
					SMG_LS_A0 = 1;
				
					P0 = 0x5b;
					while(KEY_MATRIX_PORT==0x0b);
					P0 = 0x00;
				
				}else if(KEY_MATRIX_PORT == 0x0d){
					SMG_LS_A2 = 0;
					SMG_LS_A1 = 1;
					SMG_LS_A0 = 0;
				
					P0 = 0x4f;
					while(KEY_MATRIX_PORT==0x0d);
					P0 = 0x00;
					
				}else if(KEY_MATRIX_PORT == 0x0e){
					SMG_LS_A2 = 0;
					SMG_LS_A1 = 1;
					SMG_LS_A0 = 1;
				
					P0 = 0x66;
					while(KEY_MATRIX_PORT==0x0e);
					P0 = 0x00;
				
				}
				
				
			}
		
	}
}