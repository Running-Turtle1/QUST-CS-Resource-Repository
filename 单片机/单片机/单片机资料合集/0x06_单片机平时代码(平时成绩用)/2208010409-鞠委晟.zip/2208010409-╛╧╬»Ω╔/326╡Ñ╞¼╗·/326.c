#include "reg52.h"
typedef unsigned int u16;
/*P07 P06 P05 P04 P03 P02 P01 P00
  dp  g   f   e    d   c  b   a
	0   0   1   1    1   1  1   1 0x3f 0
	0   1   0   1    1   0  1   1 0x5b 2
	0   1   0   0    1   1  1   1 0x4f 3
	0   1   1   0    0   1  1   0 0x66 4
	0   1   1   0    1   1  0   1 0x6d 5
  0   1   1   1    1   1  0   1 0x7d 6
  0   0   0   0    0   1  1   1 0x07 7
  0   1   1   1    1   1  1   1	0x7f 8
	*/
#define SMG_A_2_DP_PORT P0

/*u8 code smg_duan_codes[]=()*/
sbit KEY_K1=P3^1;

sbit KEY_K2=P3^0;

sbit KEY_K3=P3^2;

sbit KEY_K4=P3^3;

void delay_10us(u16 ten_us){
	while(ten_us--);
}
void main(){
	SMG_A_2_DP_PORT=0x00;
	while(1){
	if(KEY_K1==0||KEY_K2==0||KEY_K3==0||KEY_K4==0){
		delay_10us(1000);
		if(KEY_K1==0){
			SMG_A_2_DP_PORT=0x3f;
			while(KEY_K1==0);
	SMG_A_2_DP_PORT=~SMG_A_2_DP_PORT;
			SMG_A_2_DP_PORT=0x00;
		}
		
		else if(KEY_K2==0){
			SMG_A_2_DP_PORT=0x06;
			while(KEY_K2==0);
	SMG_A_2_DP_PORT=~SMG_A_2_DP_PORT;
			SMG_A_2_DP_PORT=0x00;
		}
		else if(KEY_K3==0){
			SMG_A_2_DP_PORT=0x5b;
			while(KEY_K3==0);
	SMG_A_2_DP_PORT=~SMG_A_2_DP_PORT;
			SMG_A_2_DP_PORT=0x00;
		}
		else if(KEY_K4==0){
			SMG_A_2_DP_PORT=0x4f;
			while(KEY_K4==0);
	SMG_A_2_DP_PORT=~SMG_A_2_DP_PORT;
			SMG_A_2_DP_PORT=0x00;
		}
/*	while(1){
		SMG_A_2_DP_PORT=0x3f;
		delay_10us(50000);
		SMG_A_2_DP_PORT=0x06;
		delay_10us(50000);
		SMG_A_2_DP_PORT=0x5b;
		delay_10us(50000);
		SMG_A_2_DP_PORT=0x4f;
		delay_10us(50000);
		SMG_A_2_DP_PORT=0x66;
		delay_10us(50000);
		SMG_A_2_DP_PORT=0x6d;
		delay_10us(50000);
		SMG_A_2_DP_PORT=0x7d;
		delay_10us(50000);
		SMG_A_2_DP_PORT=0x07;
		delay_10us(50000);
		SMG_A_2_DP_PORT=0x7f;
		delay_10us(50000);
		
	}*/

}}}