#include"reg52.h"
#define SMG_A_2_DP_PORT P0
#define	KEY_MATRIX_PORT P1
// 					/E1	/E2		E3
//74HC138		4		 5		6
//shineng   0    0  	1
//					A2	 A1		A0
//					P24	 P23  P22
sbit SMG_LS_A2 = P2^4;
sbit SMG_LS_A1 = P2^3;
sbit SMG_LS_A0 = P2^2;





typedef unsigned int u16;
typedef unsigned char u8;
u16 num=0,num_1=0;
u8 code smg_duan_codes[]={
	0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f
};

u8 int0_trigger_count=0;

sbit LED_D1=P2^0;
sbit LED_D2=P2^1;
sbit INT0_KEY_K3=P3^2;
sbit INT1_KEY_K4=P3^3;


//dp g f e d c b a   
// 0 0 1 1 1 1 1 1  liang 0 0x3f
// 0 0 0 0 0 1 1 0  liang 1	0x06
// 0 1 0 1 1 0 1 1  liang 2 0x5b
// 0 1 0 0 1 1 1 1  liang 3 0x4f
// 0 1 1 0 0 1 1 0  liang 4 0x66
// 0 1 1 0 1 1 0 1  liang 5 0x6d
// 0 1 1 1 1 1 0 1  liang 6 0x7d
// 0 0 0 0 0 1 1 1  liang 7 0x07
// 0 1 1 1 1 1 1 1  liang 8 0x7f
// 0 1 1 0 1 1 1 1  liang 9 0x6f
// 1 1 1 1 0 1 1 1  liang a 0x6f
// 1 1 1 1 1 1 1 1  liang b 0x6f
// 0 0 1 1 1 0 0 1  liang c 0x6f
// 0 0 1 1 1 1 1 1  liang d 0x3f
// 0 1 1 1 1 0 0 1  liang e 0x79
// 0 1 1 1 0 0 0 1  liang f 0x71

void delay_10us(u16 ten_us){
	
	while(ten_us--);

}

void time0_1ms_init()
{
	TMOD=0x01;
	TH0=0xFC;
	TL0=0x18;
	ET0=1;
	EA=1;
	TR0=1;
}	
void time1_50ms_init()
{
	TMOD|=0x10;
	TH1=0x3c;
	TL1=0xb0;
	ET1=1;
	EA=1;
	TR1=1;
}	


void time0_isr() interrupt 1
{
	
	TH0=0xFC;
	TL0=0x18;
	num++;
	if(num%1000==0)
	{
		LED_D1=!LED_D1;
	}
	
	
}
void time1_isr() interrupt 3
{
	
	TH1=0x3c;
	TL1=0xb0;
	num_1++;
	if(num_1%20==0)
	{
		LED_D2=!LED_D2;
	}
	
	
}
void main(){
	
	time0_1ms_init();

	time1_50ms_init();
	while(1){

	}
	}