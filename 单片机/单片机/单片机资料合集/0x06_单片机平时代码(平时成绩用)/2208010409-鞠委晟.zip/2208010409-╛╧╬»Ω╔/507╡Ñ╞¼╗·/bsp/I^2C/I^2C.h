#ifndef __I^2C_H__
#define __I^2C_H__

void iic_write_byte(u8);
void iic_wait_ask();
void iic_write_byte(u8);

#endif