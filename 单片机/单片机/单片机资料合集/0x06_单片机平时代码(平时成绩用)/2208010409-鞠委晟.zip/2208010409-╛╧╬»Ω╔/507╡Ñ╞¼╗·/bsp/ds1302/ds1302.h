#ifndef __DS1302_H__
#define __DS1302_H__
void ds1302_write_byte(u8 addr,u8 dat);
void ds1302_read_real_time(void);

void ds1302_init(void);
#endif