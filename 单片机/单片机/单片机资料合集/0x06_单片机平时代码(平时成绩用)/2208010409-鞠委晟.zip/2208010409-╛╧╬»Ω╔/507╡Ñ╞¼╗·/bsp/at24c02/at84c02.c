#include"public.h"
void at24c02_write_byte()
{

}