#ifndef __DS1302_H__
#define __DS1302_H__


#endif