#ifndef __PUBLIC_H__
#define __PUBLIC_H__
//����ͷ�ļ�
#include<reg52.h>
#include "led.h"
#include "step.h"
#include "I^2C.h"
#include "intrins.h"
#include "lcd1602.h"
#include "ds18b20.h"
#define u8 unsigned int
#define u16 unsigned char


#define LED_PORT P2
sbit LCD_RS=P2^6;
sbit LCD_RW=P2^5;
sbit LCD_EN=P2^7;

sbit IIC_SDA=P2^0;
sbit IIC_SCL=P2^1;

sbit LED__D1=P2^0;
sbit LED__D2=P2^1;
sbit LED__D3=P2^2;
sbit LED__D4=P2^3;
sbit LED__D5=P2^4;
sbit LED__D6=P2^5;
sbit LED__D7=P2^6;
sbit LED__D8=P2^7;
sbit KEY_K1=P3^0;
sbit KEY_K2=P3^1;
sbit KEY_K3=P3^2;
sbit KEY_K4=P3^3;
sbit STET_IN_D=P1^0;
sbit STET_IN_C=P1^1;
sbit STET_IN_B=P1^2;
sbit STET_IN_A=P1^3;
sbit DS1302_RST=P3^5;
sbit DS1302_CLK=P3^6;

sbit DS18B20_DATA=P3^7;


sbit DS1302_DATA=P3^7;
u8 g_READ_RTC_ADDR[7] = {0x81, 0x83, 0x85, 0x87, 0x89, 0x8B, 0x8D}; 
u8 g_WRITE_RTC_ADDR[7] = {0x80, 0x82, 0x84, 0x86, 0x88, 0x8A, 0x8C};

u8 g_DS1302_SET_TIME[7] = {0x00, 0x00, 0x19, 0x21, 0x05, 0x02, 0x24};
u8 g_DS1302_REAL_TIME[7]=0;

//��������

void delay_10us(u16 ten_us);


void lcd1602_write_cmd(u8 cmd);

void lcd1602_show_data(u8 x,u8 y,u8 dat);

void lcd1602_init();
void lcd1602_write_data(u8 dat);
#endif