#include "public.h"
#include "led.h"
#include "ds1302.h"
#include "ds18b20.h"
void main()
{
lcd1602_show_string(2024,06,mon)
	while(1)
{


}
}
