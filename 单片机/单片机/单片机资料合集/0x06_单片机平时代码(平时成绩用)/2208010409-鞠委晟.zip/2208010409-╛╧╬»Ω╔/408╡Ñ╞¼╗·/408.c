#include"reg52.h"
#define SMG_A_2_DP P0
#define KEY_MATRIX_PORT P1
// 					/E1	/E2		E3
//74HC138		4		 5		6
//shineng   0    0  	1
//					A2	 A1		A0
//					P24	 P23  P22





typedef unsigned int u16;
typedef unsigned char u8;

sbit KEY_K1 = P3^0;
sbit KEY_K2 = P3^1;
sbit KEY_K4 = P3^3;

sbit SMG_LS_A2 = P2^4;
sbit SMG_LS_A1 = P2^3;
sbit SMG_LS_A0 = P2^2;

sbit INTO_KEY_K3=P3^2;
sbit LED_D1=P2^0;
sbit LED_D2=P2^1;

//dp g f e d c b a   
// 0 0 1 1 1 1 1 1  liang 0 0x3f
// 0 0 0 0 0 1 1 0  liang 1	0x06
// 0 1 0 1 1 0 1 1  liang 2 0x5b
// 0 1 0 0 1 1 1 1  liang 3 0x4f
// 0 1 1 0 0 1 1 0  liang 4 0x66
// 0 1 1 0 1 1 0 1  liang 5 0x6d
// 0 1 1 1 1 1 0 1  liang 6 0x7d
// 0 0 0 0 0 1 1 1  liang 7 0x07
// 0 1 1 1 1 1 1 1  liang 8 0x7f
// 0 1 1 0 1 1 1 1  liang 9 0x6f
// 1 1 1 1 0 1 1 1  liang a 0x6f
// 1 1 1 1 1 1 1 1  liang b 0x6f
// 0 0 1 1 1 0 0 1  liang c 0x6f
// 0 0 1 1 1 1 1 1  liang d 0x3f
// 0 1 1 1 1 0 0 1  liang e 0x79
// 0 1 1 1 0 0 0 1  liang f 0x71
int int0_trigger_count=0;
/*
hang1 P17
hang2 P16
hang3 P15
hang4 P14

lie1	lie2	lie3	lie4
P13		P12		P11		P10


*/
void delay_10us(u16 ten_us){
	
	while(ten_us--);

}
u8 smg_duan_codes[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
void extern_int0_init()
{
//��һ���ţ��½�����Ч

IT0=1;
//�ڶ����ţ�INTO�Ŀ�����
EX0=1;
//�������ţ��ܿ�����
EA=1;
}
void extern_int0_isr() interrupt 0
{

delay_10us(1000);
if(INTO_KEY_K3==0)
{
LED_D1=~LED_D1;
int0_trigger_count++;

}

}

void smg_display()
{
SMG_LS_A2=0;
SMG_LS_A1=0;
SMG_LS_A0=1;
}
void extern_int1_init()
{
IT1=1;
//�ڶ����ţ�INTO�Ŀ�����
EX1=1;
//�������ţ��ܿ�����
EA=1;
}
void extern_int1_isr() interrupt 2
{
	
	delay_10us(1000);
	
	if(KEY_K4 == 0){
		LED_D2 = ~LED_D2;
		
	}
		
}
void main(){
smg_display();
extern_int0_init();
extern_int1_init();
	while(1){
	if(int0_trigger_count>=9)
	{
	int0_trigger_count=0;
	}
	SMG_A_2_DP=smg_duan_codes[int0_trigger_count];
	}
			
				
			
		
	
}