#include"reg52.h"

typedef  unsigned int u16;
typedef  unsigned char u8;

sbit LED_D1 = P2^0;
sbit LED_D2 = P2^1;
sbit LED_D3 = P2^2;
sbit LED_D4 = P2^3;
sbit LED_D5 = P2^4;
sbit LED_D6 = P2^5;
sbit LED_D7 = P2^6;
sbit LED_D8 = P2^7;


sbit KEY_K4 = P3^3;
sbit KEY_K3 = P3^2;
sbit KEY_K2 = P3^0;
sbit KEY_K1 = P3^1;

u8 code led_codes[]={
	
	0xfe, 0xfd, 0xfb, 0xf7, 0xef, 0xdf, 0xbf, 0x7f
};

void delay_10us(u16 ten_us)//10us
{
	while(ten_us--);
}

void extern_int0_init()
{
	IT0 = 1;
	
	EX0 = 1;
	
	EA = 1;

}

void extern_int0_isr() interrupt 0
{
	u16 i;
	while(1){
		delay_10us(10000);
		
		for(i = 0;i<8;i++){
			delay_10us(10000);
			P2=led_codes[i];
			
		}
	}
	
	
	
		
}


void main()
{
	LED_D1 = 1;
	LED_D2 = 1;
	LED_D3 = 1;
	LED_D4 = 1;
	LED_D5 = 1;
	LED_D6 = 1;
	LED_D7 = 1;
	LED_D8 = 1;
	
	extern_int0_init();
	
	
	
	/*
	while(1){
		u16 i;
		for(i = 0;i<8;i++){
			delay_10us(10000);
			P2=led_codes[i];
			
		}
		
	}*/
	
	/*
	while(1)
	{
		if(KEY_K1 == 0){
			delay_10us(1000);
			
			if(KEY_K1 == 0){
				
				LED_D1 = 0;
				
				while(KEY_K1 == 0);
				LED_D1 = ~LED_D1;
			}
			
		}else if(KEY_K2 == 0){
			delay_10us(1000);
			
			if(KEY_K2 == 0){
				
				LED_D2 = 0;
				
				while(KEY_K2 == 0);
				LED_D2 = ~LED_D2;
			}
		}else if(KEY_K3 == 0){
			delay_10us(1000);
			
			if(KEY_K3 == 0){
				
				LED_D3 = 0;
				
				while(KEY_K3 == 0);
				LED_D3 = ~LED_D3;
			}
		}else if(KEY_K4 == 0){
			delay_10us(1000);
			
			if(KEY_K4 == 0){
				
				LED_D4 = 0;
				
				while(KEY_K4 == 0);
				LED_D4 = ~LED_D4;
			}
		}
		
	}
	*/
}