#include"reg52.h"
#define LEDS_PORT P2
typedef u16 unsigned int ;
typedef u8 unsigned char;

void delay_10us(u16 ten_us)//10us
{
	while(ten_us--);
}

void main()
{
	while(1)
	{
		u8 i;
		LEDS_PORT = 0X01;
		/*
		//D1
		LEDS_PORT = 0Xfe;
		delay_10us(50000);
		//D2
		LEDS_PORT = 0Xfd;
		delay_10us(50000);
		//D3
		LEDS_PORT = 0Xfb;
		delay_10us(50000);
		//D4
		LEDS_PORT = 0XF7;
		delay_10us(50000);
		//D5
		LEDS_PORT = 0Xef;
		delay_10us(50000);
		//D6
		LEDS_PORT = 0Xdf;
		delay_10us(50000);
		//D7
		LEDS_PORT = 0Xbf;
		delay_10us(50000);
		//D8
		LEDS_PORT = 0X7f;
		delay_10us(50000);
		*/
		for( i=0;i<8;i++)
		{
			LEDS_PORT = ~(0X01<<i);
		}
		
	}
}