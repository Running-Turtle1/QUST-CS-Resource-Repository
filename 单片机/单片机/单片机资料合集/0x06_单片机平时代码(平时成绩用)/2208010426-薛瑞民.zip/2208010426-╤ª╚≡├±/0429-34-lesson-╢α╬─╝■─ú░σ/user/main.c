#include "public.h"


void main(){
	
	
	LED_D1 = 1;
	LED_D2 = 1;
	LED_D3 = 1;
	LED_D4 = 1;
	LED_D5 = 1;
	LED_D6 = 1;
	LED_D7 = 1;
	LED_D8 = 1;
	
	extern_int0_init();
	/*
	u8	step = 0;
	while(1){
	 //leds_show_all_on();
	 //leds_show_all_off();
	 //leds_show_run();
		
		step_motor_4_beat_control(step);
		step++;
		if(step>=4){
			step = 0;
		}
		//5ms
		//step:0~3,һ���ĸ�beat
		delay_10us(5000);
		
	}
	*/

}