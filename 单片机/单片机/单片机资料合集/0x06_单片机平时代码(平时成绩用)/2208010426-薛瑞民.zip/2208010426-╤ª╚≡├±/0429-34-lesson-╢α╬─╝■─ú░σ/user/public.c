#include "public.h"



void delay_10us(u16 ten_us){

	while(ten_us--);
}