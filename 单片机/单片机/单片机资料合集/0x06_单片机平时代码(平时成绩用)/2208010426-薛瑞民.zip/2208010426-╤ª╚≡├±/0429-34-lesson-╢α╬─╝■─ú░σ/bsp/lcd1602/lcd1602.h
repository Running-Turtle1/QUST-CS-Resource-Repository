#ifndef __LCD1602_H__
#define __LCD1602_H__

void lcd1602_write_cmd(u8 cmd);
void lcd1602_write_dat(u8 dat);
void lcd1602_show_data(u8 x,u8 y,u8 dat);
void  lcd1602_init();


#endif