#ifndef __LED_H__
#define __LED_H__


void leds_show_all_on(void);
void leds_show_all_off(void);
void leds_show_run(void);

#endif