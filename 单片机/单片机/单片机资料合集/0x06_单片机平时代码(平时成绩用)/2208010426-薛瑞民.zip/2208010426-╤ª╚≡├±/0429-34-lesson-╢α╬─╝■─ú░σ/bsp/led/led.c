#include "public.h"

//led.c�а�����������ʵ��
//�������е�led  �͵�ƽ
void leds_show_all_on(void){
		LEDS_PORT =0x00;
		//LED_D1 = 0;
}
//Ϩ�����е�led  �ߵ�ƽ
void leds_show_all_off(void){
		LEDS_PORT =0xff;
		//LED_D1 = 0;
}


//������
void leds_show_run(void){
	
		
		/*
			LEDS_PORT = 0xfe;
			delay_10us(50000);
			
		
			LEDS_PORT = 0xfd;
			delay_10us(50000);
			
			LEDS_PORT = 0xfb;
			delay_10us(50000);
			
			LEDS_PORT = 0xf7;
			delay_10us(50000);
			
			LEDS_PORT = 0xef;
			delay_10us(50000);
			
			LEDS_PORT = 0xdf;
			delay_10us(50000);
			
			LEDS_PORT = 0xbf;
			delay_10us(50000);
			
			LEDS_PORT = 0x7f;
			delay_10us(50000);
			*/
			u16 i;
			
			LEDS_PORT = 0x01;
			
			while(1){
				for(i =0;i<8;i++){
					
				LEDS_PORT =~(0x01 << i);
				delay_10us(50000);
				
			}
			
			}
			
			
			
			
		
}