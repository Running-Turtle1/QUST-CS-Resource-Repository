#ifndef __TIMER_H__
#define __TIMER_H__

void extern_int0_isr(void) interrupt 0;
void extern_int0_init(void);


#endif