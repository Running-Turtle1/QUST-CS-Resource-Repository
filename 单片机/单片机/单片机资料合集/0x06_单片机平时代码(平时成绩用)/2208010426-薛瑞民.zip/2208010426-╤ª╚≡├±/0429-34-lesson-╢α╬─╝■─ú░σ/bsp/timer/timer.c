#include"pulbic.h"
void extern_int0_init()
{
	IT0 = 1;
	
	EX0 = 1;
	
	EA = 1;

}

void extern_int0_isr() interrupt 0
{
	u16 i;
	while(1){
		delay_10us(10000);
		
		for(i = 0;i<8;i++){
			delay_10us(10000);
			P2=led_codes[i];
			
		}
	}
	
		
}
