#ifndef __STEP_MOTOR_H__
#define __STEP_MOTOR_H__

void step_motor_4_beat_control( u8 step );

#endif