#include<reg52.h>
#include<intrins.h>
#include "DS1302.H"
#include "LCD1602.h"

typedef unsigned char uint8;
typedef unsigned int uint16;

unsigned char TIME[7] = {0, 0, 0x12, 0x13, 0x09, 0x06, 0x22};
 unsigned char code READ_RTC_ADDR1[7] = {0x81, 0x83, 0x85, 0x87, 0x89, 0x8b, 0x8d}; 
 unsigned char code WRITE_RTC_ADDR[7] = {0x80, 0x82, 0x84, 0x86, 0x88, 0x8a, 0x8c};


void Ds1302Init(){
     unsigned char n;
	 Ds1302Write(0x8e,0x00); //�ر�д����
	 for(n=0;n<7;n++){ //д��7���ֽڵ�ʱ���źţ�����ʱ��������
	    Ds1302Write(WRITE_RTC_ADDR[n],TIME[n]);	 
	 }
	 Ds1302Write(0x8e,0x80);//��д����

}

void Ds1302ReadTime(){
	 unsigned char n;
	 for(n=0;n<7;n++){//��ȡ7���ֽڵ�ʱ���źţ�����ʱ��������
	    TIME[n]=Ds1302Read(READ_RTC_ADDR1[n]);
	 }
}

void main()
{
	LCD_Init();
//	Ds1302Init();	

	while(1)
	{	
		Ds1302ReadTime();
		LCD_ShowNum(2,1,20,2);	//��
		LCD_ShowNum(2,3,TIME[6]/16,1);
		LCD_ShowNum(2,4,TIME[6]%16,1);
		LCD_ShowChar(2,5,'.');
		LCD_ShowNum(2,6,TIME[4]/16,1);	//��
		LCD_ShowNum(2,7,TIME[4]%16,1);
		LCD_ShowChar(2,8,'.');
		LCD_ShowNum(2,9,TIME[3]/16,1);	//��
		LCD_ShowNum(2,10,TIME[3]%16,1);

		LCD_ShowNum(1,1,TIME[2]/16,1); //ʱ
		LCD_ShowNum(1,2,TIME[2]%16,1);
		LCD_ShowChar(1,3,'-');
		LCD_ShowNum(1,4,TIME[1]/16,1); //��
		LCD_ShowNum(1,5,TIME[1]%16,1);
		LCD_ShowChar(1,6,'-');
		LCD_ShowNum(1,7,TIME[0]/16,1); //��
		LCD_ShowNum(1,8,TIME[0]%16,1);
	}	
}