#include "reg52.h"
#define SMG A_2_DP_PORT P0
#define LED_MATRIX_COL_PORT P0
#define	KEY_MATRIX_PORT P1

typedef unsigned int u16;
typedef unsigned char u8;
sbit HC595_SER = P3 ^ 4;
sbit HC595_SRCLK = P3 ^ 6;
sbit HC595_RCLK = P3 ^ 5;

sbit INT0_KEY_K3=P3^2;

sbit INT1_KEY_K4=P3^3;

u8 code led_matrix_col_codes[] = {
    0x7f, 0xbf, 0xdf, 0xef, 0xf7, 0xfb, 0xfd, 0xfe
};
u16 num=0,num_1=0;

sbit DC_MOTOR_PIN=P1^0;//����ֱ���������

void dc_motor_init(void)   //�������
{
      DC_MOTOR_PIN=0;//�رյ��
   
}



u8 code led_matrix_row_codes[][8] = {
                      {0x00,0x00,0x3e,0x41,0x41,0x41,0x3e,0x00},     //0
                      {0x00,0x00,0x00,0x21,0x7f,0x01,0x00,0x00},     //1
                      {0x00,0x00,0x27,0x45,0x45,0x45,0x39,0x00},     //2
	                  {0x00,0x00,0x2a,0x49,0x49,0x49,0x36,0x00},     //3
                      {0x00,0x00,0x0c,0x14,0x24,0x7f,0x04,0x00},     //4
                      {0x00,0x00,0x72,0x51,0x51,0x51,0x4e,0x00},     //5
                      {0x00,0x00,0x3e,0x49,0x49,0x49,0x26,0x00},     //6
                      {0x00,0x00,0x40,0x40,0x4f,0x50,0x60,0x00},     //7
                      {0x00,0x00,0x36,0x49,0x49,0x49,0x36,0x00},     //8
                      {0x00,0x00,0x32,0x49,0x49,0x49,0x3e,0x00}, 
};

void delay_10us(u16 ten_us)
{
    while (ten_us--);
}


void led_matrix_display_init()
{
    LED_MATRIX_COL_PORT = 0xff; //
}


void hc595_write_data(u8 dat)
{
    u16 i = 0;
    for (i = 0; i < 8; i++)
    {
        HC595_SER = dat >> 7;
        dat <<= 1;
        HC595_SRCLK = 0;
        delay_10us(1);
        HC595_SRCLK = 1;
        delay_10us(1);
    }
    HC595_RCLK = 0;
    delay_10us(1);
    HC595_RCLK = 1;
    delay_10us(1);
}
 /*
 		��Ƭ���ǿ�����

 
 */

void time1_50ms_init()
{
	TMOD=0x10;
	TH1=0x3c;
	TL1=0xb0;
	ET1=1;
	EA=1;
	TR1=1;
}	
void time1_isr() interrupt 3
{
	
	TH1=0x3c;
	TL1=0xb0;
	num_1++;
	if(num_1%20==0)
	{
		DC_MOTOR_PIN=!DC_MOTOR_PIN;
	}
	
	
}

void main()
{	
	time1_50ms_init();
    while (1)
    {
     	 /*
		 DC_MOTOR_PIN=1;//�������
		 delay_10us(50000);
		 delay_10us(50000);

		  DC_MOTOR_PIN=0;//���ֹͣ
		 delay_10us(50000);
		 delay_10us(50000);
		 */
	
       }
}