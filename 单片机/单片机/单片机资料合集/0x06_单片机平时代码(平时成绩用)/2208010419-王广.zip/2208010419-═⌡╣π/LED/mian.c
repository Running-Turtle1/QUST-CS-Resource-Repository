#include"reg52.h"
sbit D1 = P2^0;
sbit D2 = P2^1;
sbit D3 = P2^2;
sbit D4 = P2^3;
sbit D5 = P2^4;
sbit D6 = P2^5;
sbit D7 = P2^6;
sbit D8 = P2^7;

typedef unsigned char u8;

typedef unsigned int u16;
#define LEDS_PORT P2

void delay_10us(u16 ten_us){	 //��ʱ����
	while(ten_us--);
}
//delay_10us(1)��ʱ1us;
/*
   0xfe:  1 | 1 | 1 | 1 | 1 | 1 | 1 | 0     
   		 P27 P26 P25 P24 P23 P22 P21 P20
		 D8  D7	 D6	 D5	 D4	 D3	 D2	 D1
   
 1 0 0 1:9    1 0 1 1:b   1 1 0 0:c   1 1 0 1:d    1 1 1 0: e	 1 1 1 1: f  


*/

/*void main()	//������ (�˿ڸ�ֵ)
{
   //LEDS_PORT=0xfe;
  //D1��
   LEDS_PORT = 0xfe;
   delay_10us(50000);
   
   LEDS_PORT = 0xfd;
   delay_10us(50000);  

   LEDS_PORT = 0xfb;
   delay_10us(50000);

   LEDS_PORT = 0xf7;
   delay_10us(50000); 
   
   LEDS_PORT = 0xef;
   delay_10us(50000); 

   LEDS_PORT = 0xdf;
   delay_10us(50000); 

   LEDS_PORT = 0xbf;
   delay_10us(50000); 

   LEDS_PORT = 0x7f;
   delay_10us(50000); 
	
}*/
void main()
{
   u8 i;
   LEDS_PORT=0xfe;
   while(1)
   {
   	 for(i=0;i<8;i++)
	 {
	   LEDS_PORT=~(0x01<<i);//��λ����
	   delay_10us(50000);
	 }
   }


}