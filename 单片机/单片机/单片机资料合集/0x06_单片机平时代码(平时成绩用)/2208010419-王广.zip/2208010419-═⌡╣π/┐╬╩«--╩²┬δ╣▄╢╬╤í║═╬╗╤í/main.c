#include"reg52.h"
#define SMG_A_2_DP_PORT P0	   // ��������ܵ�8�Σ�a~dp���Ķ˿�P0
#define LED_MATRTX_COL_PORT P0 //LED���������˿�
typedef unsigned int u16;
typedef unsigned char u8;


sbit KEY_K1=P3^1;

sbit KEY_K2=P3^0;

sbit KEY_K3=P3^2;

sbit KEY_K4=P3^3;
  



sbit HC595_SER=P3^4;

sbit HC595_SRCLK=P3^6;

sbit HC595_RCLK=P3^5;

void delay_10us(u16 ten_us){	 //��ʱ����
	while(ten_us--);
}


u8 code smg_duan_codes[]={
	0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f, //1~10
	0x77,0x7c,0x39,0x5e,0x19,0x71 //A~E
};	   


/*			  											 
     
    �����������ʾ����0
	dp  g  f  e  d  c  b  a
	0   0  1  1	 1	1  1  1		   :0 0x3f
	0	0  0  0	 0	1  1  0		    1 0x06
	0   1  0  1	 1	0  1  1			2 0x5b
	0   1  0  0	 1	1  1  1			3 0x4f
	0	1  1  0	 0	1  1  0			4 0x66
	0	1  1  0	 1	1  0  1			5 0x6d
	0	1  1  1	 1	1  0  1			6 0x7d
	0	0  0  0	 0	1  1  1			7 0x07
	0	1  1  1	 1	1  1  1			8 0x7f
	0	1  1  0	 1	1  1  1			9 0x6f
	P0=0x3f;

	a 77  b 7c  c 39  d 5e  e 79  f 71
	
*/

void led_matrix_diaplay_init()
{  
   
   LED_MATRTX_COL_PORT=0x00;
}

void hc595_write_data(u8 dat)
{
	 /*
	        D7  D6  D5  D4 ,  D3  D2  D1  D0
	dat:    0   0   0   0     0   0   0   1
	��һ������D7����HC595_SER				   (dat<<=1  dat=dat<<1)
	dat>>7:	*   *   *   *     *   *   *   0

			D6  D5  D4 ,  D3  D2  D1  D0
	dat<<=1:0   0   0,    0   0   0   1   * 

	 */
	  u8 i=0;
	  for(i=0;i<8;i++)
	  {
		  HC595_SER=dat>>7;
		  dat<<=1;
	      HC595_SRCLK=0;
	      delay_10us(1);
	      HC595_SRCLK=1;
	      delay_10us(1);
	  }
	  	  HC595_RCLK=0;
	      delay_10us(1);
	      HC595_RCLK=1;
	      delay_10us(1);
     
}  


void main() 
{
     led_matrix_diaplay_init();
	 hc595_write_data(0x01);
    while(1)
	{
	}
}
