#include"reg52.h"
typedef unsigned int u16;

#define SMG_A_2_DP_PORT P0

sbit KEY_K1=P3^1;

sbit KEY_K2=P3^0;

sbit KEY_K3=P3^2;

sbit KEY_K4=P3^3;

void delay_10us(u16 ten_us){	 //��ʱ����
	while(ten_us--);
}

//u8 code smg_

/*			  
     
    �����������ʾ����0
	dp  g  f  e  d  c  b  a
	0   0  1  1	 1	1  1  1		   :0 0x3f
	0	0  0  0	 0	1  1  0		    1 0x06
	0   1  0  1	 1	0  1  1			2 0x5b
	0   1  0  0	 1	1  1  1			3 0x4f
	0	1  1  0	 0	1  1  0			4 0x66
	0	1  1  0	 1	1  0  1			5 0x6d
	0	1  1  1	 1	1  0  1			6 0x7d
	0	0  0  0	 0	1  1  1			7 0x07
	0	1  1  1	 1	1  1  1			8 0x7f
	0	1  1  0	 1	1  1  1			9 0x6f
	P0=0x3f;

	a 77  b 7c  c 39  d 5e  e 79  f 71
	
*/

void main()
{
    while(1)
	{
			if(KEY_K1==0)
	  {

	       delay_10us(1000);
		   if(KEY_K1==0)
		   {	
		        SMG_A_2_DP_PORT = 0x3f;
		   		while(KEY_K1==0);	
			 	SMG_A_2_DP_PORT = !SMG_A_2_DP_PORT;
				SMG_A_2_DP_PORT = 0x00;
		   
		   }
     
      }

	  else 		if(KEY_K2==0)
	  {

	       delay_10us(1000);
		   if(KEY_K2==0)
		   {
		   		SMG_A_2_DP_PORT = 0x06;
				while(KEY_K2==0);
				
				SMG_A_2_DP_PORT = !SMG_A_2_DP_PORT;
				SMG_A_2_DP_PORT = 0x00;
		   
		   }
     
      }

	  else 		if(KEY_K3==0)
	  {

	       delay_10us(1000);
		   if(KEY_K3==0)
		   {
		   		SMG_A_2_DP_PORT = 0x5b;
				while(KEY_K3==0);
				
				SMG_A_2_DP_PORT = !SMG_A_2_DP_PORT;
				SMG_A_2_DP_PORT = 0x00;
		   
		   }
     
      }

	  else 		if(KEY_K4==0)
	  {

	       delay_10us(1000);
		   if(KEY_K4==0)
		   {
		   		SMG_A_2_DP_PORT = 0x4f;
				while(KEY_K4==0);
				
				SMG_A_2_DP_PORT = !SMG_A_2_DP_PORT;
				SMG_A_2_DP_PORT = 0x00;
		   
		   }
     
      }
	
	}

  /* while(1)
   {
   	  SMG_A_2_DP_PORT = 0x3f;
	  delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x06;
	  delay_10us(50000);
      SMG_A_2_DP_PORT = 0x5b;
	  delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x4f;
	   delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x66;
	  delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x6d;
	   delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x7d;
	   delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x07;
	   delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x7f;
	   delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x6f;
	   delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x77;
		delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x7c;
		delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x39;
		delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x5e;
		delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x79;
		delay_10us(50000);
	  SMG_A_2_DP_PORT = 0x71;
		delay_10us(50000);	 

   } */
}
