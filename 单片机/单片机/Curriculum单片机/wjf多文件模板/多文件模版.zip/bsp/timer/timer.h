#ifndef __PUBLIC_H__
#define __PUBLIC_H__

void time1_1ms_init(void);
void time0_1ms_init(void);
#endif